paragraph 1 is here

<table>
	<tr>
		<td>a</td>
		<td>b</td>
	</tr>
	<tr>
		<td>c</td>
		<td>d</td>
	</tr>
</table>

more markdown here

< this is not an html tag

<thisisnotanhtmltag

but this is:

<img src="file.jpg"
     alt="some alt aligned with src attribute" title="some text" />

<span class="test">some inline **md**</span>

<span>some inline **md**</span>

self-closing on block level:

<p>this is a paragraph</p>
<hr style="clear: both;" />

something **bold**.

<custom />

# h1

<custom multi="line" something="hi" />

## h2

p <img src="file.jpg"
       alt="some alt aligned with src attribute"
       title="some text" />
   something

p <img src="file.jpg"
       alt="some alt aligned with src attribute"
       title="some text" />
    something

p is < than 5
    this is code

this paragraph contains a <!-- multi
line html comment -->
newline
