this is __strong__ and this is **strong**.

this is _em_ and this is *em*.

_`code`_ __`code`__

*`code`**`code`**`code`*

Hey *this is
italic*

Hey **this is
bold**

**strong text***emphasized text*

*emphasized text***strong text**

**strong text**_emphasized text_

*emphasized text*__strong text__

__strong text__*emphasized text*

_emphasized text_**strong text**

simple_word_with_underscores

this is text, _this is emph_ simple_word_with_underscores text again.
