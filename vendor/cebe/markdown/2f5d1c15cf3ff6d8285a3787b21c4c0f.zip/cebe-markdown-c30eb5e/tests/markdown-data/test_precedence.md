Not a headline but two HR:

***
---

---
***

