here is the url: http://www.cebe.cc/

here is the url: http://www.cebe.cc

here is the url: http://www.cebe.cc/ and some text

using http is cool and http:// is the beginning of an url.

link should be url decoded: http://en.wikipedia.org/wiki/Mase_%28disambiguation%29

link in the end of the sentence: See this http://example.com/.

this one is in parenthesis (http://example.com/).

this one is in parenthesis (http://example.com:80/?id=1,2,3).

... (see http://en.wikipedia.org/wiki/Port_(computer_networking)).

... (see https://en.wikipedia.org/wiki/Port_(computer_networking)_more).

... (see https://en.wikipedia.org/wiki/Port_(computer_networking)_more). ... (see http://en.wikipedia.org/wiki/Port_(computer_networking)).

... (see https://en.wikipedia.org/wiki/Port_(computer_networking)_more)....(http://en.wikipedia.org/wiki/Port_(computer_networking)).

... (see http://en.wikipedia.org/wiki/Port)

... (see http://en.wikipedia.org/wiki/Port).

http://www.cebe.cc, http://www.cebe.net, and so on

[link to http://www.google.com/](http://www.google.com/)