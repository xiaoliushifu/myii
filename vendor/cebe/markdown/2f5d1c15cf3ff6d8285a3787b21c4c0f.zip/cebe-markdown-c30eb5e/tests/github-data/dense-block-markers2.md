Now we need to set:
```php
'session' => [
    'cookieParams' => [
        'path' => '/path1/',
    ]
],
```
and
```php
'session' => [
    'cookieParams' => [
        'path' => '/path2/',
    ]
],
```

In the following starts a Blockquote:
> this is a blockquote

par
***
par

This is some text
# Headline1
more text