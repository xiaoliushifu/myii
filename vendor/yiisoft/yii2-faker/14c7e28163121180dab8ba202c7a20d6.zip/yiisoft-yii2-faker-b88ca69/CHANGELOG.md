Yii Framework 2 faker extension Change Log
==============================================

2.0.3 March 01, 2015
--------------------

- no changes in this release.


2.0.2 January 11, 2015
----------------------

- no changes in this release.


2.0.1 December 07, 2014
-----------------------

- no changes in this release.


2.0.0 October 12, 2014
----------------------

- no changes in this release.


2.0.0-rc September 27, 2014
---------------------------

- Chg #4622: Simplified the way of creating a Faker fixture template file (qiangxue)


2.0.0-beta April 13, 2014
-------------------------

- Initial release.
