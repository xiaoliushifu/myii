<?php
namespace Codeception\Exception;

class InjectionException extends \Exception
{
}
