<?php
namespace Codeception\Exception;

class ConditionalAssertionFailed extends \PHPUnit_Framework_AssertionFailedError
{
}
