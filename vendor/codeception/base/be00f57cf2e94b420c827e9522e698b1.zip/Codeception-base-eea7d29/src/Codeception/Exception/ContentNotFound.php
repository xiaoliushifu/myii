<?php
namespace Codeception\Exception;

class ContentNotFound extends \PHPUnit_Framework_AssertionFailedError
{
}
