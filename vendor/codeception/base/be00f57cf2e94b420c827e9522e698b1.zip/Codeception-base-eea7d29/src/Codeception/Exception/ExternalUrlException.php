<?php

namespace Codeception\Exception;

class ExternalUrlException extends \Exception
{
}
