# PHPUnit Overrides

Codeception heavily relies on PHPUnit for running and managing tests.
Not all PHPUnit classes fit the needs of Codeception, that's why they were extended or redefined. 