<?php
namespace Codeception\Lib\Interfaces;

/**
 * Modules for API testing
 */
interface API
{
}
