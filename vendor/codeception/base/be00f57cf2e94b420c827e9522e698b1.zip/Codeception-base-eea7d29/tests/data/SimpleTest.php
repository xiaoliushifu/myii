<?php
class SampleTest extends PHPUnit_Framework_TestCase
{
    public function testOfTest() {
        $this->assertTrue(true);
    }
    
}