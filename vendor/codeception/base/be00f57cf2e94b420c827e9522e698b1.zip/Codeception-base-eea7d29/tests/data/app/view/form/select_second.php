<html>
<body>
<form action="/form/complex" method="POST">
    <select id="select1">
        <option value="select1_value1">Value1</option>
        <option value="select1_value2">Value2</option>
    </select>
    <select id="select2">
        <option value="select2_value1">Value1</option>
        <option value="white" selected>        no_whitespaces    </option>
    </select>
    <input type="submit" value="Submit" />
</form>
</body>
</html>
