<html>
<body>
<form action="/form/complex" method="POST">
    <label for="age">Select your age</label>
    <select name="age" id="age">
        <option value="20">21</option>
        <option value="21">20</option>
    </select>
    <input type="submit" value="Submit" />
</form>
</body>
</html>