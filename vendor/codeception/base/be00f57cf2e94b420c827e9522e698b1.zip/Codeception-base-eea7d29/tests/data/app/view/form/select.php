<html>
<body>
<form action="/form/complex" method="POST">
    <label for="age">Select your age</label>
    <select name="age" id="age">
        <option value="child">below 13</option>
        <option value="teenage">13-21</option>
        <option value="adult">21-60</option>
        <option value="oldfag" selected="selected">60-100</option>
        <option value="dead">100-210</option>
    </select>
    <input type="submit" value="Submit" />
</form>
</body>
</html>